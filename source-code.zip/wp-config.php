<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache


define('WP_AUTO_UPDATE_CORE', true);
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'chaurichauramaho_wp_iifj1' );

/** MySQL database username */
define( 'DB_USER', 'chaurichauramaho_wp_ktwli' );

/** MySQL database password */
define( 'DB_PASSWORD', 'RRQm&wY6K5y3Uk&n' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '|*Vx|_)kt@NGPAGt[P)~Q(#2(U-5tDni3Z]kb2*c2]4XEuY0**WV%ogl~MK1T2(0');
define('SECURE_AUTH_KEY', '7W#4R]6GB@Nil(4cax9e+ZmrQJn352K+mz0M~1)hPF@JUmlhJ9+Lt8Rq##7G5wO!');
define('LOGGED_IN_KEY', 'Ran2g2x1nvW82||4428KorjM&%#K_e_m0x6-;k0kkc4vT6U0I]UGDQWZ(@O76j|5');
define('NONCE_KEY', '*Xh:D8Cpey[O~Icja8I_+B4uJv5+4g1~HMu52P18n)K;6I59]*TRRa4DqWoT-iJ]');
define('AUTH_SALT', 'x206!K)9hVkf%Y4y~M*Be7P%G*:tO63|XxShb|7(j-yoGAHf#|5#G+kw62!/qkvP');
define('SECURE_AUTH_SALT', 'T#+!09Y!7&h(261&ctO6ZcB86w1]+%x)08:@;fnE(UZ:4HzE4NLkP_#m24enyd1P');
define('LOGGED_IN_SALT', 'F9%Q245A2Jv~56puKHtm;J96S4b#w%hgQhm03~z@G0Vq:yB7!13a5F;##S0++gc/');
define('NONCE_SALT', '+j1&|a18/:-r3#s*m1s9KXO4Lg6Box#1Ez24:9;*1[N2lj7#Qb)]C22XfDS3S44#');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = '0dhPvfnGR_';


define('WP_ALLOW_MULTISITE', true);

define('WP_DEBUG', false);
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
