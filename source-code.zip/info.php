<?php 

phpinfo();
 ?>